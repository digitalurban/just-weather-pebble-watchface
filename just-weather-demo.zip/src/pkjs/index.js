// Entry point required by Pebble build system.
// This simply requires the actual app module so the builder finds a top-level entry.
require('./app');
